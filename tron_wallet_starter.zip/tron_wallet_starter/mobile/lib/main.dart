import 'package:flutter/material.dart';

void main() => runApp(const TronWalletApp());

class TronWalletApp extends StatelessWidget {
  const TronWalletApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'TRON Wallet',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0B806B)),
        scaffoldBackgroundColor: const Color(0xFFF5F7F8),
        fontFamily: 'Roboto',
      ),
      home: const WalletHome(),
    );
  }
}

class WalletHome extends StatelessWidget {
  const WalletHome({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('محفظتي'),
          actions: [
            IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF075E54), Color(0xFF15977D)],
                ),
                borderRadius: BorderRadius.circular(22),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('الرصيد الإجمالي', style: TextStyle(color: Colors.white70)),
                  SizedBox(height: 10),
                  Text('0.00 USDT',
                    style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold)),
                  SizedBox(height: 8),
                  Text('شبكة TRON · وضع تجريبي',
                    style: TextStyle(color: Colors.white70, fontSize: 12)),
                ],
              ),
            ),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(child: _ActionTile(
                  icon: Icons.south_west, title: 'إيداع', onTap: () => _notice(context))),
                const SizedBox(width: 12),
                Expanded(child: _ActionTile(
                  icon: Icons.north_east, title: 'إرسال', onTap: () => _notice(context))),
              ],
            ),
            const SizedBox(height: 24),
            const Text('آخر العمليات',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Card(
              child: ListTile(
                leading: const CircleAvatar(child: Icon(Icons.receipt_long)),
                title: const Text('لا توجد عمليات بعد'),
                subtitle: const Text('ستظهر الإيداعات والتحويلات هنا'),
              ),
            ),
            const SizedBox(height: 14),
            const Card(
              child: Padding(
                padding: EdgeInsets.all(14),
                child: Row(
                  children: [
                    Icon(Icons.shield_outlined, color: Color(0xFF0B806B)),
                    SizedBox(width: 10),
                    Expanded(child: Text(
                      'هذه نسخة أولية تجريبية. لا ترسل أموالاً حقيقية إليها.',
                      style: TextStyle(fontSize: 12),
                    )),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  static void _notice(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('سيتم تفعيل هذه الوظيفة بعد ربط الخادم وشبكة الاختبار.')),
    );
  }
}

class _ActionTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;
  const _ActionTile({required this.icon, required this.title, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20),
          child: Column(
            children: [
              Icon(icon, size: 28, color: const Color(0xFF0B806B)),
              const SizedBox(height: 8),
              Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      ),
    );
  }
}
