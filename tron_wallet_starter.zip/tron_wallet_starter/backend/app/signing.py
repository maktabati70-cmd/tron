class CustodySigner:
    \"\"\"Security boundary for transaction signing.

    Intentionally no software private-key implementation is included.
    Production implementation must call an HSM/KMS or isolated audited signer.
    Enforce destination allow/deny rules, daily limits, approval thresholds,
    transaction simulation/energy limits, and operator authorization here.
    \"\"\"

    def sign_tron_transaction(self, unsigned_transaction: dict) -> dict:
        raise NotImplementedError("Integrate HSM/KMS-backed signer before withdrawals are enabled")
