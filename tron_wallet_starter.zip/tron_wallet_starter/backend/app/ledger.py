from decimal import Decimal, ROUND_DOWN

USDT_QUANTUM = Decimal("0.000001")

def quantize_usdt(value: Decimal) -> Decimal:
    return value.quantize(USDT_QUANTUM, rounding=ROUND_DOWN)

def quote_fee(gross: Decimal, fee_bps: int) -> tuple[Decimal, Decimal]:
    if gross <= 0:
        raise ValueError("gross amount must be positive")
    if not 0 <= fee_bps <= 10_000:
        raise ValueError("invalid fee rate")
    fee = quantize_usdt(gross * Decimal(fee_bps) / Decimal(10_000))
    recipient = quantize_usdt(gross - fee)
    if recipient <= 0:
        raise ValueError("amount is too small after fees")
    return fee, recipient

# Production ledger rules:
# - Every journal entry has at least two postings and total debits == total credits.
# - Never update a balance as a standalone mutable number.
# - Lock the user's available balance row within a DB transaction.
# - Use a unique idempotency key for every client withdrawal request.
# - Hold gross amount before broadcasting; settle only after confirmed chain outcome.
# - Reverse with compensating journal entries; never delete financial history.
