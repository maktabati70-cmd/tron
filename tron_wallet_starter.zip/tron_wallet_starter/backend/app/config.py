from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_env: str = "development"
    database_url: str = "postgresql+psycopg://wallet:change-me@localhost:5432/tron_wallet"
    tron_network: str = "nile"
    tron_rpc_url: str = "https://nile.trongrid.io"
    usdt_contract: str = "TESTNET_CONTRACT_ADDRESS_REQUIRED"
    service_fee_bps: int = 50
    min_confirmations: int = 20
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
