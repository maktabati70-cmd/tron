from decimal import Decimal
from pydantic import BaseModel, Field, field_validator

class FeeQuoteRequest(BaseModel):
    gross_amount: Decimal = Field(gt=0, max_digits=20, decimal_places=6)

class FeeQuote(BaseModel):
    gross_amount: Decimal
    fee_amount: Decimal
    recipient_amount: Decimal
    fee_rate_bps: int
    currency: str = "USDT"

class WithdrawalRequest(BaseModel):
    destination: str = Field(min_length=34, max_length=36)
    gross_amount: Decimal = Field(gt=0, max_digits=20, decimal_places=6)
    idempotency_key: str = Field(min_length=16, max_length=100)

    @field_validator("destination")
    @classmethod
    def tron_address_shape(cls, value: str) -> str:
        # Shape check only. Production must perform Base58Check and network validation.
        if not value.startswith("T"):
            raise ValueError("TRON address must start with T")
        return value
