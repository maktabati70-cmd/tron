from decimal import Decimal
from fastapi import FastAPI, HTTPException
from app.config import settings
from app.schemas import FeeQuoteRequest, FeeQuote, WithdrawalRequest
from app.ledger import quote_fee

app = FastAPI(
    title="TRON Wallet API",
    version="0.1.0",
    description="Development scaffold. No real-money operations are enabled."
)

@app.get("/health")
def health():
    return {
        "status": "ok",
        "environment": settings.app_env,
        "network": settings.tron_network,
        "withdrawals_enabled": False
    }

@app.get("/v1/wallet")
def wallet_summary():
    # Mock response only. Replace with authenticated account/ledger query.
    return {
        "currency": "USDT",
        "available_balance": "0.00",
        "pending_balance": "0.00",
        "network": settings.tron_network,
        "mode": "mock"
    }

@app.post("/v1/fees/quote", response_model=FeeQuote)
def fee_quote(payload: FeeQuoteRequest):
    try:
        fee, recipient = quote_fee(payload.gross_amount, settings.service_fee_bps)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    return FeeQuote(
        gross_amount=payload.gross_amount,
        fee_amount=fee,
        recipient_amount=recipient,
        fee_rate_bps=settings.service_fee_bps
    )

@app.post("/v1/withdrawals")
def create_withdrawal(payload: WithdrawalRequest):
    # Deliberately disabled: requires authentication, DB transaction,
    # balance reservation, risk checks, signer/HSM and on-chain reconciliation.
    raise HTTPException(
        status_code=503,
        detail="Withdrawals are disabled in this starter until custody controls are implemented."
    )
