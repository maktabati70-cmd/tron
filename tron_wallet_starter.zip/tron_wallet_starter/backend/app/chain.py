from dataclasses import dataclass
from decimal import Decimal

@dataclass(frozen=True)
class TransferObservation:
    txid: str
    sender: str
    recipient: str
    amount: Decimal
    contract: str
    block_number: int
    solidified: bool

class TronAdapter:
    \"\"\"Replace with a production-tested TRON client/indexer integration.

    Required safeguards:
    - Verify exact USDT contract address for selected network.
    - Verify Transfer event signature, token decimals, recipient and amount.
    - Track block height and solidification/finality.
    - Persist cursor and make event processing idempotent.
    - Handle provider outages, duplicate events and chain reorganizations.
    \"\"\"

    def get_confirmed_usdt_transfers(self, address: str) -> list[TransferObservation]:
        raise NotImplementedError("Connect a trusted TRON indexer/RPC provider")

    def broadcast_signed_transaction(self, signed_tx: dict) -> str:
        raise NotImplementedError("Broadcast only transactions produced by approved signer")
