from decimal import Decimal
from app.ledger import quote_fee

def test_fee_quote():
    fee, recipient = quote_fee(Decimal("100.000000"), 50)
    assert fee == Decimal("0.500000")
    assert recipient == Decimal("99.500000")

def test_rounding_down():
    fee, recipient = quote_fee(Decimal("0.000009"), 50)
    assert fee == Decimal("0.000000")
    assert recipient == Decimal("0.000009")
